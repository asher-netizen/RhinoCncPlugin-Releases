@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-CncPlugin.ps1"
if errorlevel 1 (
  echo Installation did not complete. Keep this message for support.
) else (
  echo Ready. Start Rhino 8 and run CNC. Future updates load after a normal restart.
)
pause
