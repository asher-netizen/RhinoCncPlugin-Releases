# Copy this installer beside cnc-release.json in an extracted official release.
# It stages a separate directory and changes only next-start plugin registration.
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($PSScriptRoot)
$manifest=Get-Content -LiteralPath (Join-Path $root 'cnc-release.json') -Raw | ConvertFrom-Json
if($manifest.Format -ne 1 -or $manifest.Repository -ne 'Frailey-Woodworks/CncPlugin' -or $manifest.PluginId -ne '180fdd35-441b-4c37-ac77-3d5c36333ddf' -or $manifest.Platform -ne 'win-x64' -or $manifest.RhinoMajor -ne 8){throw 'Incompatible CNC release manifest'}
$destination=Join-Path $env:LOCALAPPDATA ('Frailey Woodworks\CncPlugin\Builds\'+[Guid]::NewGuid().ToString('N'))
$prefix=$root.TrimEnd('\')+'\'
foreach($property in $manifest.Files.PSObject.Properties){
 $source=[IO.Path]::GetFullPath((Join-Path $root $property.Name))
 if(!$source.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or $property.Name.Contains(':') -or (Get-Item -LiteralPath $source).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Unsafe release path'}
 if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $property.Value){throw ('Checksum mismatch: '+$property.Name)}
}
New-Item -ItemType Directory -Path $destination | Out-Null
foreach($property in $manifest.Files.PSObject.Properties){
 $target=Join-Path $destination $property.Name
 New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($target)) | Out-Null
 Copy-Item -LiteralPath (Join-Path $root $property.Name) -Destination $target
 if((Get-FileHash -LiteralPath $target).Hash -ne $property.Value){throw 'Staged file checksum mismatch'}
}
Copy-Item -LiteralPath (Join-Path $root 'cnc-release.json') -Destination $destination
$plugin=Join-Path $destination 'CncPlugin.rhp'
$assembly=[Reflection.AssemblyName]::GetAssemblyName($plugin)
$declared=[Version]$manifest.Version
$declared=[Version]::new($declared.Major,$declared.Minor,[Math]::Max(0,$declared.Build),[Math]::Max(0,$declared.Revision))
if($assembly.Name -ne 'CncPlugin' -or $assembly.Version -ne $declared){throw 'Plugin version mismatch'}
foreach($required in @('CncPlugin.deps.json','CncPlugin.runtimeconfig.json','Eto.dll','System.Text.Json.dll','System.Text.Encodings.Web.dll','manifoldc.dll','tbb12.dll','SimulationWorker\CncSimulationWorker.exe','SimulationWorker\CncSimulationWorker.dll','SimulationWorker\CncSimulationWorker.deps.json','SimulationWorker\CncSimulationWorker.runtimeconfig.json','SimulationWorker\Rhino.Inside.dll')){
 if(!(Test-Path -LiteralPath (Join-Path $destination $required))){throw ('Release payload is incomplete: '+$required)}
}
$key='HKCU:\Software\McNeel\Rhinoceros\8.0\Plug-Ins\180fdd35-441b-4c37-ac77-3d5c36333ddf\PlugIn'
$old=(Get-ItemProperty -LiteralPath $key -Name FileName -ErrorAction SilentlyContinue).FileName
if($old -and (Test-Path -LiteralPath $old) -and [Reflection.AssemblyName]::GetAssemblyName($old).Version -gt $assembly.Version){throw 'A newer CNC version is already registered. Use its rollback control explicitly.'}
[IO.File]::WriteAllText((Join-Path $destination 'previous-plugin-path.txt'),[string]$old)
if(!(Test-Path -LiteralPath $key)){New-Item -Path $key -Force | Out-Null}
Set-ItemProperty -LiteralPath $key -Name FileName -Value $plugin
$protection='HKCU:\Software\McNeel\Rhinoceros\8.0\Global Options\Plug-ins\180fdd35-441b-4c37-ac77-3d5c36333ddf'
if(!(Test-Path -LiteralPath $protection)){New-Item -Path $protection -Force | Out-Null}
New-ItemProperty -LiteralPath $protection -Name LoadProtection -Value 1 -PropertyType DWord -Force | Out-Null
Write-Output "CNC $($manifest.Version) is staged for your next normal Rhino start. Open Rhino files and saved CNC jobs were not changed."
